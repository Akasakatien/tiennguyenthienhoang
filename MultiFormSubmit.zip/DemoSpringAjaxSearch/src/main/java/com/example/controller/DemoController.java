package com.example.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.dao.InforDAO;
import com.example.dao.ProductDAO;
import com.example.model.AjaxResponeBody;
import com.example.model.Infor;
import com.example.model.Product;

@Controller
@RequestMapping("demo")
public class DemoController {

	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap map) {
		InforDAO inforDAO = new InforDAO();
		map.put("infor", inforDAO.inforModel());
		return "demo/index";
	}
	
	@PostMapping("/search")
	public ResponseEntity<?> search(@RequestBody Infor infor) {
		AjaxResponeBody ajaxResponeBody = new AjaxResponeBody();
		ProductDAO productDAO = new ProductDAO();
		List<Product> products = productDAO.findAll();
		if(products.isEmpty()){
			ajaxResponeBody.setMsg("No product found!");
		}else {
			ajaxResponeBody.setMsg("Success");
		}
		ajaxResponeBody.setProducts(products);
		return ResponseEntity.ok(ajaxResponeBody);
	}
}

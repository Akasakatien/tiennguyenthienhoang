package com.example.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.dao.InforDAO;
import com.example.model.Infor;

@Controller
@RequestMapping("multiForm")
public class MultiFormController {
	
	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap map) {
		InforDAO dao = new InforDAO();
		List<Infor> list_infor = dao.setListInfo();
		//map.put("inforEntity", new Infor("",""));
		map.put("list_infor", list_infor);
		return "demo/multiForm";
	}
	@RequestMapping(value="/submit", method = RequestMethod.POST)
	public String submit(@ModelAttribute("inforEntity") Infor infor, HttpSession session) {
		session.setAttribute("inforSession", infor);
		return "demo/multiForm";
	}
}

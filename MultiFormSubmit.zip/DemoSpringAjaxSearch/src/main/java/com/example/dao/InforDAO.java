package com.example.dao;

import java.util.ArrayList;
import java.util.List;

import com.example.model.Infor;

public class InforDAO {
	public Infor inforModel() {
		return new Infor();
	}
	
	public List<Infor> setListInfo() {
		List<Infor> infors = new ArrayList<Infor>();
		infors.add(new Infor("01", "infor 1"));
		infors.add(new Infor("02", "infor 2"));
		infors.add(new Infor("03", "infor 3"));
		infors.add(new Infor("04", "infor 4"));
		infors.add(new Infor("05", "infor 5"));
		infors.add(new Infor("06", "infor 6"));	
		return infors;
	}
}

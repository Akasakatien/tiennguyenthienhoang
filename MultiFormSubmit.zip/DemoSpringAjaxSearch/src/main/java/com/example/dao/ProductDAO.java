package com.example.dao;

import java.util.ArrayList;
import java.util.List;

import com.example.model.Product;

public class ProductDAO {
	public Product find() {
		return new Product();
	}
	
	public List<Product> findAll() {
		List<Product> products = new ArrayList<Product>();
		products.add(new Product("01", "pro1", "a11", "a12", "b11", "b12"));
		products.add(new Product("02", "pro2", "a21", "a22", "b21", "b22"));
		products.add(new Product("03", "pro3", "a31", "a32", "b31", "b32"));
		return products;
	}
}

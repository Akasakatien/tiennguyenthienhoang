package com.example.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.example.model.ValidateModel;

@Controller
@RequestMapping("validate")
public class ValidateController {
	
	Map<String, String> errorList;
	List<String> formatStrings = Arrays.asList("yyy/MM/dd", "yyy.MM.dd");
	DateFormat fmd = new SimpleDateFormat("yyyy/MM/dd");
	
	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap map) {
		ValidateModel validateModel = new ValidateModel();
		errorList = new HashMap<String, String>();
		map.put("validateModel", validateModel);
		map.put("errors", errorList);
		return "demo/validate";
	}
	
	@PostMapping("/submitValidate")
	public String search(@ModelAttribute("validateModel") ValidateModel validateModel, ModelMap map) {
		errorList = new HashMap<String, String>();
		validate(errorList, validateModel);
		map.put("errors", errorList);
		if(errorList.isEmpty()){
			validateModel.setResult("hihihihahaha");
		}
		return "demo/validate";
	}
	
	private void validate(Map<String, String> errorList, ValidateModel validateModel) {
		String regex = ".|//";
		Date currentDate = java.sql.Date.valueOf(java.time.LocalDate.now());
		Date dateFromParsed = null;
		Date dateToParsed = null;
		if(!validateModel.getDateFrom().isEmpty()){
			dateFromParsed = tryParse(validateModel.getDateFrom());			
		}
		if(!validateModel.getDateTo().isEmpty()){
			dateToParsed = tryParse(validateModel.getDateTo());
		}
		
		if(validateModel.getDateFrom().isEmpty()){
			errorList.put("errorDateFrom", "Required Date From");
		}else {
			if(dateFromParsed.after(currentDate)){
				errorList.put("errorDateFrom", "Required Date From less than today");
			}
		}
		if(validateModel.getDateTo().isEmpty()){
			errorList.put("errorDateTo", "Required Date To");
		}
		if(dateFromParsed != null && dateToParsed != null){
			if(!dateFromParsed.before(dateToParsed) && !dateFromParsed.equals(dateToParsed)){
				errorList.put("errorDateToLessThanDateFrom", "Date from must be less than date to");
			}
		}	
	}
	
	private Date tryParse(String dateString)
	{
	    for (String formatString : formatStrings)
	    {
	        try
	        {
	            return new SimpleDateFormat(formatString).parse(dateString);
	        }
	        catch (ParseException e) {}
	    }

	    return null;
	}
}

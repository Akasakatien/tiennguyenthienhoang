package com.example.dao;

import com.example.model.Infor;

public class InforDAO {
	public Infor inforModel() {
		return new Infor();
	}
}

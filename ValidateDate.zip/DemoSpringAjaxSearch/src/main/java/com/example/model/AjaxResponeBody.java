package com.example.model;

import java.util.List;

public class AjaxResponeBody {
	private String msg;
	private List<Product> products;

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

}

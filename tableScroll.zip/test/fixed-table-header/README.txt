A Pen created at CodePen.io. You can find this one at https://codepen.io/akasakatien/pen/yqwNaN.

 A fixed header on a scrollable table, using just CSS
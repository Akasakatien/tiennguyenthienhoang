(function() {
  var tables = document.querySelectorAll('.table-scroll table');
  
  [].forEach.call(tables, function(table) {
    var headCells = table.querySelectorAll('thead tr th');
    var bodyCells = table.querySelectorAll('tbody tr:first-child td');
    
    document.addEventListener("DOMContentLoaded", setTableHead);
    window.addEventListener('resize', setTableHead, true);
    table.addEventListener('updateTableHead', setTableHead);  
    
    function setTableHead() {
      for (var h = 0, b=0; h < headCells.length; h++, b++) {
        
        var colspan = headCells[h].getAttribute('colspan')        
        if (colspan) {
          colspan = parseInt(colspan);
          var sumWidth = 0;
          for (var c = 0; c < colspan; c++ ) {
            sumWidth += bodyCells[b+c].offsetWidth
          }
          headCells[h].style.width = sumWidth;
          b += c-1;
        } else {
          headCells[h].style.width = bodyCells[b].offsetWidth + 'px';
        }
      }
    };
  });
  
})();

